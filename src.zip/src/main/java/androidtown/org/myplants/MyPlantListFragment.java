package androidtown.org.myplants;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import com.bumptech.glide.Glide;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MyPlantListFragment extends Fragment {
    PlantslistFragment plistFragment;
    ReadExcel ReadExcelFile;
    ArrayAdapter<String> arrayAdapter;


    FragmentManager fmanager;
    FragmentTransaction ftrans;
    jxl.Sheet sheet;

    ListView listView;
    ArrayList<Item> mItems = new ArrayList<Item>();

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_myplants,
                container, false); //create a view for the fragment
        listView = (ListView)rootView.findViewById(R.id.plantListView1);
        arrayAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1);



        ImageButton plus= (ImageButton) rootView.findViewById(R.id.plus);
        fmanager = getFragmentManager();
        ftrans = fmanager.beginTransaction();;

        plistFragment = new PlantslistFragment();

       ReadExcelFile.readExcelFile(getContext(),"mine.xls");

       
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ftrans.replace(R.id.container,plistFragment).commit();
            }
        });

        return rootView;
    }

}