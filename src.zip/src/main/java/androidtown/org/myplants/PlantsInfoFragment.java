
package androidtown.org.myplants;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.bumptech.glide.Glide;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class PlantsInfoFragment extends Fragment {
    PlantslistFragment plistFragment;
    SaveExcel exl;
    MyPlantListFragment myPlantListFragment;

    FragmentManager fmanager;
    FragmentTransaction ftrans;
    jxl.Sheet sheet;

    String name_t;
    String picture_t;
    int size_t;
    int level_t;
    String feature_t;
    String watering_t;

    TextView name;
    TextView size;
    TextView level;
    TextView feature;
    TextView watering;
    ImageView photo;
    ImageButton plus;

    EditText eNickname;
    ArrayList<Item> mItems = new ArrayList<Item>();

    //돌아가기 버튼
    Button plist_btn;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_plantsinfo,
                container, false); //create a view for the fragment
        EditText eNickname=(EditText) rootView.findViewById(R.id.nickname);
        name=(TextView) rootView.findViewById(R.id.plant_name);
        size=(TextView) rootView.findViewById(R.id.plant_size);
        level=(TextView) rootView.findViewById(R.id.plant_level);
        feature=(TextView) rootView.findViewById(R.id.plant_feature);
        watering=(TextView) rootView.findViewById(R.id.plant_watering);
        photo=(ImageView) rootView.findViewById(R.id.plant_photo);
        plus= (ImageButton) rootView.findViewById(R.id.plus);

        fmanager = getFragmentManager();
        ftrans = fmanager.beginTransaction();

        plistFragment = new PlantslistFragment();

        sheet = ((MainActivity)MainActivity.context_main).sheet;

        if(sheet != null) {
            int colTotal = sheet.getColumns();    // 전체 컬럼
            int rowIndexStart = 1;                  // row 인덱스 시작
            int rowTotal = sheet.getColumn(colTotal-1).length;

            Bundle bundle = this.getArguments();
            String plantName = bundle.getString("selecPlant");
            // Log.i("test", plantName);

            StringBuilder sb;
            for(int row=rowIndexStart;row<rowTotal;row++) {
                sb = new StringBuilder();
                String var = sheet.getCell(0, row).getContents();
                if(var.equals(plantName)){
                    name_t = sheet.getCell(0, row).getContents();
                    picture_t = sheet.getCell(1, row).getContents();
                    watering_t = sheet.getCell(2, row).getContents();
                    size_t = Integer.parseInt(sheet.getCell(4, row).getContents());
                    feature_t = sheet.getCell(6, row).getContents();
                    level_t = Integer.parseInt(sheet.getCell(8, row).getContents());
                }
            }
        }

        String url1='"'+picture_t+'"';
        Glide.with(this).load(picture_t).into(photo);

        try {
            URL url = new URL(url1);
            URLConnection conn = url.openConnection();
            conn.connect();
            BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
            Bitmap bm = BitmapFactory.decodeStream(bis);
            bis.close();
            photo.setImageBitmap(bm);
        } catch (Exception e) {
        }

        name.setText(name_t);
        size.setText(Integer.toString(size_t));
        level.setText(Integer.toString(level_t));
        feature.setText(feature_t);
        watering.setText(watering_t);

        String nickname=eNickname.getText().toString();
        mItems.add(new Item(name_t, size_t, level_t, feature_t, watering_t, nickname, picture_t));

        exl = new SaveExcel();
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ftrans.replace(R.id.container, myPlantListFragment).commit();
            }
        });

        //돌아가기 버튼
        plist_btn = rootView.findViewById(R.id.plantinfoback);
        plist_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ftrans.replace(R.id.container, plistFragment).commit();
            }
        });

        return rootView;
    }

}